1. This is an online IDE created using PHP, HTML, CSS, JS.
2. The languages supported in this IDE are C,C++, Python, PHP, Java, Dart.
3. Ace code editor's api is used for the editor.
4. The execution is performed by the respective programming language shells.
5. The source files are saved in the temp folder with extension depending on the programming language selected by the user.